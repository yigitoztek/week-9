
package javaapplication93;


public interface Supporter {
    int heal(GameCharacter target);
}
