package javaapplication93;

public class JavaApplication93 {
    public static void main(String[] args) {
        System.out.println("--- 1. Testing Invalid Inputs ---");
        Warrior invalidTest = new Warrior("TestDummy", 150, -50, 10);
        System.out.println(invalidTest.getCharacterInfo());

        System.out.println("\n--- 2. Creating Team and Testing Duplicate Name ---");
        Team heroes = new Team();
        Warrior w1 = new Warrior("Aragorn", 10, 200, 30);
        Mage m1 = new Mage("Gandalf", 12, 120, 60);
        Healer h1 = new Healer("Elrond", 8, 110, 25);

        heroes.addCharacter(w1);
        heroes.addCharacter(m1);
        heroes.addCharacter(h1);

        heroes.addCharacter(new Warrior("Aragorn", 5, 100, 10));

        heroes.displayTeam();

        Warrior boss = new Warrior("Golem", 15, 450, 40);
        System.out.println("\nEnemy Appeared: " + boss.getCharacterInfo());

        GameCharacter[] targets = {w1, m1, h1};

        System.out.println("\n--- 3. Battle Simulation (2 Rounds) ---");
        for (int round = 1; round <= 2; round++) {
            System.out.println("\n>>> ROUND " + round + " <<<");

            heroes.attackAll(boss);
            System.out.println("Enemy Status: " + boss.getCharacterInfo());

            if (boss.isAlive()) {
                System.out.println("\n" + boss.getName() + " attacks all team members!");
                for (GameCharacter member : targets) {
                    if (member.isAlive()) {
                        int dealt = boss.attack(member);
                        System.out.println(boss.getName() + " dealt " + dealt + " damage to " + member.getName()
                                + " (HP: " + member.getHealth() + "/" + member.getMaxHealth() + ")");
                    }
                }
            }

            System.out.println("\nTeam healing phase:");
            heroes.healTeam();
            heroes.displayTeam();
        }

        System.out.println("\n--- 4. Search and Remove Operations ---");
        GameCharacter found = heroes.findByName("Gandalf");
        if (found != null) {
            System.out.println("Found character: " + found.getCharacterInfo());
        } else {
            System.out.println("Character not found.");
        }

        heroes.removeCharacter("Elrond");
        heroes.displayTeam();
    }
}
