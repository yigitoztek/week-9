
package javaapplication93;


public interface Attacker {
    int attack(GameCharacter target); 
}
